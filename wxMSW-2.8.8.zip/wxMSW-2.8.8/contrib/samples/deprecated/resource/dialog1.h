/*
 * dialog1.h
 * Window identifiers file written by Dialog Editor
 */

#define ID_TEXTCTRL104 104
#define ID_STATICBOX101 101
#define ID_DIALOG100 100
#define ID_STATIC107 107
#define ID_BUTTON108 108
#define ID_BUTTON109 109
#define ID_LISTBOX105 105
#define ID_CHECKBOX106 106
#define ID_RADIOBOX102 102
