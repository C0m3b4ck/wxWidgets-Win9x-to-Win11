/////////////////////////////////////////////////////////////////////////////
// Name:        web.h
// Purpose:     wxWeb: portable web browser-related class
// Author:      Julian Smart
// Modified by:
// Created:     2001-08-21
// RCS-ID:      $Id: web.h 35650 2005-09-23 12:56:45Z MR $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_WEB_H_
#define _WX_WEB_H_

/*
 * wxWeb
 * Miscellaneous web functions
 */

class wxWeb
{
public:
//// Ctor/dtor
    wxWeb() {};

//// Operations

protected:
};


#endif //_WX_WEB_H_

