#include <wx/wx.h>

class MyApp : public wxApp {
	public:
		bool OnInit() {
			wxFrame * frame = new wxFrame(NULL, wxID_ANY, "Hello wxWidgets!", 
			wxDefaultPosition, wxSize(450, 350));
			frame->Show(true);
			return true;
		}
};

IMPLEMENT_APP(MyApp)
